# Access NFC Lab (Android)

A Kotlin starter project for learning Android NFC and testing a credential application that you control.

## Included
- NFC availability check and tag scanning in Android reader mode.
- Displays tag technologies and UID when exposed by the tag.
- Reports whether NDEF is advertised and the record count.
- HCE service for one local demo AID: `F0010203040506`.
- Demo HCE answers SELECT with `ACCESS NFC LAB` followed by `9000`.

## Important limitations
This is not a universal access-card copier. Android HCE emulates ISO-DEP/APDU applications. It does not reproduce arbitrary 125 kHz RFID, arbitrary NFC UIDs, MIFARE Classic behavior, or proprietary secure-card protocols. A UID alone is generally not sufficient to authenticate to a modern access system. Secure credentials can use cryptographic challenge-response and secret keys.

Only scan or use credentials you own or are explicitly authorized to administer. For a real building deployment, ask the access-control administrator/vendor to issue a mobile credential or provision a supported mobile-access profile. The reader/controller may need configuration or firmware support.

## Build
1. Install Android Studio and a compatible Android SDK.
2. Open this folder as an existing project.
3. Allow Gradle sync to complete.
4. Connect an NFC-capable Android phone with USB debugging enabled.
5. Run the `app` configuration.

## Test scanning
1. Enable NFC in Android Settings.
2. Open Access NFC Lab and tap **Start card scan**.
3. Hold a test NFC tag against the phone's NFC antenna area.
4. Review the technology list.

## Test HCE
1. Install on an Android device that supports HCE.
2. If Android asks, select Access NFC Lab as the default service for the relevant NFC category. This setting varies by device.
3. Use a separate test reader you control, configured for AID `F0010203040506`.
4. The reader should receive `ACCESS NFC LAB` followed by `9000`.

## Real access-system integration
Identify the card technology and reader/controller model with the building administrator. If the vendor supports Android mobile credentials, integrate its approved SDK or provisioning API rather than copying a physical card.
