# Build the APK using only your Android phone

This project includes a GitHub Actions workflow that builds a debug APK in the cloud. You do not need Android Studio or a computer.

1. In your phone browser, sign in to GitHub (create a free account if needed).
2. Create a **public or private** repository, for example `AccessNfcLab`.
3. Upload the *contents* of this project folder to the repository. Keep `.github/workflows/build-apk.yml` in exactly that path. If your ZIP uploader hides dot-folders, create `.github/workflows/build-apk.yml` in GitHub's web editor and paste the workflow file contents from this project.
4. Open the repository's **Actions** tab. If prompted, enable workflows.
5. Select **Build Access NFC Lab APK**, tap **Run workflow**, then **Run workflow** again.
6. When the run finishes successfully, open it and scroll to **Artifacts**. Download `AccessNfcLab-debug-apk`.
7. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install. Android may ask you to allow your browser or file manager to install unknown apps; only allow this for the APK you just built from your own repository.

The output is a debug APK for testing, not a Play Store release. It is not signed with a personal release key.
