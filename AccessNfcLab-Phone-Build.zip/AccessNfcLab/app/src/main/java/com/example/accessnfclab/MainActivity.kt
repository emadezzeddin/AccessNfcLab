package com.example.accessnfclab

import android.app.Activity
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity(), NfcAdapter.ReaderCallback {
    private var nfcAdapter: NfcAdapter? = null
    private lateinit var status: TextView
    private lateinit var details: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
        }
        val title = TextView(this).apply {
            text = "Access NFC Lab"
            textSize = 26f
            setPadding(0, 0, 0, 12)
        }
        status = TextView(this).apply {
            textSize = 16f
            text = when {
                nfcAdapter == null -> "NFC hardware not detected."
                nfcAdapter?.isEnabled == true -> "NFC is enabled. Ready to scan."
                else -> "Turn on NFC in Android Settings."
            }
            setPadding(0, 0, 0, 16)
        }
        val scan = Button(this).apply {
            text = "Start card scan"
            setOnClickListener {
                if (nfcAdapter == null) {
                    status.text = "This device does not report NFC hardware."
                } else if (nfcAdapter?.isEnabled != true) {
                    status.text = "Enable NFC in Android Settings, then try again."
                } else {
                    status.text = "Scanning… Hold a card against the back of the phone."
                    details.text = "Waiting for a tag. This app reports public tag metadata only; it does not extract keys or clone access credentials."
                    enableReaderMode()
                }
            }
        }
        val stop = Button(this).apply {
            text = "Stop scan"
            setOnClickListener {
                nfcAdapter?.disableReaderMode(this@MainActivity)
                status.text = "Scan stopped."
            }
        }
        val detailsTitle = TextView(this).apply {
            text = "Scan results"
            textSize = 19f
            setPadding(0, 22, 0, 8)
        }
        details = TextView(this).apply {
            textSize = 14f
            text = "No card scanned yet."
        }
        val scroll = ScrollView(this).apply { addView(details) }
        outer.addView(title)
        outer.addView(status)
        outer.addView(scan)
        outer.addView(stop)
        outer.addView(detailsTitle)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        outer.addView(TextView(this).apply {
            text = "Emulation is limited to the included demo AID. Real building credentials must be provisioned by the access-control administrator."
            textSize = 12f
            setPadding(0, 18, 0, 0)
        })
        setContentView(outer)
    }

    private fun enableReaderMode() {
        nfcAdapter?.enableReaderMode(
            this, this,
            NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_NFC_F or NfcAdapter.FLAG_READER_NFC_V or
                NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK,
            null
        )
    }

    override fun onTagDiscovered(tag: Tag) {
        val id = tag.id.joinToString("") { "%02X".format(it) }
        val techs = tag.techList.joinToString("\\n") { "• $it" }
        val ndefInfo = try {
            val ndef = Ndef.get(tag)
            if (ndef != null) {
                ndef.connect()
                val count = ndef.ndefMessage?.records?.size ?: 0
                ndef.close()
                "NDEF: supported; records: $count"
            } else "NDEF: not advertised"
        } catch (e: Exception) {
            "NDEF: unavailable (${e.javaClass.simpleName})"
        }

        val report = """
            Tag detected

            UID (if exposed by tag): $id
            Technologies:
            $techs

            $ndefInfo

            Important:
            • A UID is an identifier, not a reusable cryptographic credential.
            • Secure access cards may require challenge-response authentication and secret keys.
            • Android HCE presents an ISO-DEP/APDU application; it cannot impersonate every card type or arbitrary RF UID.
        """.trimIndent()

        runOnUiThread {
            status.text = "Tag detected."
            details.text = report
        }
    }

    override fun onResume() {
        super.onResume()
        status.text = when {
            nfcAdapter == null -> "NFC hardware not detected."
            nfcAdapter?.isEnabled == true -> "NFC is enabled. Ready to scan."
            else -> "Turn on NFC in Android Settings."
        }
    }

    override fun onPause() {
        nfcAdapter?.disableReaderMode(this)
        super.onPause()
    }
}
