package com.example.accessnfclab

import android.nfc.cardemulation.HostApduService
import android.os.Bundle

/**
 * Demonstration HCE endpoint for a test reader that you control.
 * Registered AID: F0010203040506
 * SELECT response: ASCII "ACCESS NFC LAB" + 9000
 *
 * This does not accept copied card data, emulate a physical UID,
 * implement proprietary card protocols, or grant access to a real building.
 */
class DemoHostApduService : HostApduService() {
    private val selectAid = byteArrayOf(
        0x00, 0xA4.toByte(), 0x04, 0x00, 0x07,
        0xF0.toByte(), 0x01, 0x02, 0x03, 0x04, 0x05, 0x06,
        0x00
    )
    private val demoResponse =
        "ACCESS NFC LAB".toByteArray(Charsets.US_ASCII) +
            byteArrayOf(0x90.toByte(), 0x00)

    override fun processCommandApdu(commandApdu: ByteArray?, extras: Bundle?): ByteArray {
        if (commandApdu == null) return statusWord(0x6700)
        return if (commandApdu.contentEquals(selectAid)) demoResponse else statusWord(0x6D00)
    }

    override fun onDeactivated(reason: Int) = Unit

    private fun statusWord(sw: Int) = byteArrayOf(
        ((sw shr 8) and 0xFF).toByte(), (sw and 0xFF).toByte()
    )
}
